SkillBridge.AI — Entrega Database Design (FIAP GS 2025 2º sem)

Conteúdo
- skillbridge_oracle_ddl.sql  → DDL completo (Oracle 19c+)
- skillbridge_oracle_dml.sql  → Seeds/DML (≥5 linhas por tabela)
- skillbridge_oracle_dql.sql  → 3 consultas pedidas (INNER JOIN; GROUP BY; LEFT JOIN + WHERE + ORDER BY)

Instruções rápidas
1) Importe o DDL no Oracle SQL Developer Data Modeler (File > Import > DDL File) e gere os diagramas Logical/Relational.
2) Exporte o PDF com capa/sumário/objetivo e os diagramas.
3) Execute o DML e depois valide as consultas do DQL.

Obs.: Não incluir links externos (entrega final deve ser um .zip com PDF e .sql).
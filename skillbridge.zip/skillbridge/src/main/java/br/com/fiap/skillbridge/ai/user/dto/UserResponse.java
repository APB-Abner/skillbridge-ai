package br.com.fiap.skillbridge.ai.user.dto;

public record UserResponse(Long id, String nome, String email, String cpf) {}

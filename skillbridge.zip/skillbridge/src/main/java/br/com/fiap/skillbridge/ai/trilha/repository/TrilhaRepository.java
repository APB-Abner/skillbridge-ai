package br.com.fiap.skillbridge.ai.trilha.repository;
import br.com.fiap.skillbridge.ai.trilha.model.Trilha;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TrilhaRepository extends JpaRepository<Trilha, Long> {}

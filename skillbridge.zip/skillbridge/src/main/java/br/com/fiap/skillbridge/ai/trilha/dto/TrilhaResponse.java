package br.com.fiap.skillbridge.ai.trilha.dto;
public record TrilhaResponse(Long id, String titulo, String descricao, boolean ativa) {}

package br.com.fiap.skillbridge.ai.user.repository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserRepositoryTest {

    @BeforeEach
    void setUp() {
        // TODO document why this method is empty
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void deleteInBatch() {
    }

    @Test
    void existsByEmail() {
    }

    @Test
    void existsByEmailAndIdNot() {
    }

    @Test
    void existsByCpf() {
    }

    @Test
    void existsByCpfAndIdNot() {
    }
}